﻿namespace Program3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.directoryEntry1 = new System.DirectoryServices.DirectoryEntry();
            this.gardenLbl = new System.Windows.Forms.Label();
            this.ieLbl = new System.Windows.Forms.Label();
            this.quanityLbl = new System.Windows.Forms.Label();
            this.flowerLbl = new System.Windows.Forms.Label();
            this.baseLbl = new System.Windows.Forms.Label();
            this.discountLbl = new System.Windows.Forms.Label();
            this.gardenCombobox = new System.Windows.Forms.ComboBox();
            this.itemInput = new System.Windows.Forms.TextBox();
            this.quantityInput = new System.Windows.Forms.TextBox();
            this.calcButton = new System.Windows.Forms.Button();
            this.totalLbl = new System.Windows.Forms.Label();
            this.flowerscostOutput = new System.Windows.Forms.Label();
            this.baseOutput = new System.Windows.Forms.Label();
            this.discountOutput = new System.Windows.Forms.Label();
            this.totalOutput = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // gardenLbl
            // 
            this.gardenLbl.AutoSize = true;
            this.gardenLbl.Location = new System.Drawing.Point(204, 26);
            this.gardenLbl.Name = "gardenLbl";
            this.gardenLbl.Size = new System.Drawing.Size(89, 25);
            this.gardenLbl.TabIndex = 0;
            this.gardenLbl.Text = "Garden:";
            // 
            // ieLbl
            // 
            this.ieLbl.AutoSize = true;
            this.ieLbl.Location = new System.Drawing.Point(95, 79);
            this.ieLbl.Name = "ieLbl";
            this.ieLbl.Size = new System.Drawing.Size(208, 25);
            this.ieLbl.TabIndex = 1;
            this.ieLbl.Text = "Entree/Item Number:";
            this.ieLbl.Click += new System.EventHandler(this.label2_Click);
            // 
            // quanityLbl
            // 
            this.quanityLbl.AutoSize = true;
            this.quanityLbl.Location = new System.Drawing.Point(195, 127);
            this.quanityLbl.Name = "quanityLbl";
            this.quanityLbl.Size = new System.Drawing.Size(98, 25);
            this.quanityLbl.TabIndex = 2;
            this.quanityLbl.Text = "Quantity:";
            // 
            // flowerLbl
            // 
            this.flowerLbl.AutoSize = true;
            this.flowerLbl.Location = new System.Drawing.Point(150, 250);
            this.flowerLbl.Name = "flowerLbl";
            this.flowerLbl.Size = new System.Drawing.Size(143, 25);
            this.flowerLbl.TabIndex = 3;
            this.flowerLbl.Text = "Flowers Cost:";
            // 
            // baseLbl
            // 
            this.baseLbl.AutoSize = true;
            this.baseLbl.Location = new System.Drawing.Point(86, 293);
            this.baseLbl.Name = "baseLbl";
            this.baseLbl.Size = new System.Drawing.Size(207, 25);
            this.baseLbl.TabIndex = 4;
            this.baseLbl.Text = "Base Adjusted Cost:";
            this.baseLbl.Click += new System.EventHandler(this.label5_Click);
            // 
            // discountLbl
            // 
            this.discountLbl.AutoSize = true;
            this.discountLbl.Location = new System.Drawing.Point(111, 338);
            this.discountLbl.Name = "discountLbl";
            this.discountLbl.Size = new System.Drawing.Size(182, 25);
            this.discountLbl.TabIndex = 5;
            this.discountLbl.Text = "Discount Percent:";
            // 
            // gardenCombobox
            // 
            this.gardenCombobox.FormattingEnabled = true;
            this.gardenCombobox.Items.AddRange(new object[] {
            "Premium",
            "Standard",
            "Discount"});
            this.gardenCombobox.Location = new System.Drawing.Point(309, 26);
            this.gardenCombobox.MaxDropDownItems = 3;
            this.gardenCombobox.Name = "gardenCombobox";
            this.gardenCombobox.Size = new System.Drawing.Size(121, 33);
            this.gardenCombobox.TabIndex = 6;
            // 
            // itemInput
            // 
            this.itemInput.Location = new System.Drawing.Point(309, 79);
            this.itemInput.Name = "itemInput";
            this.itemInput.Size = new System.Drawing.Size(121, 31);
            this.itemInput.TabIndex = 7;
            // 
            // quantityInput
            // 
            this.quantityInput.Location = new System.Drawing.Point(309, 127);
            this.quantityInput.Name = "quantityInput";
            this.quantityInput.Size = new System.Drawing.Size(121, 31);
            this.quantityInput.TabIndex = 8;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(246, 177);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(132, 45);
            this.calcButton.TabIndex = 9;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // totalLbl
            // 
            this.totalLbl.AutoSize = true;
            this.totalLbl.Location = new System.Drawing.Point(172, 378);
            this.totalLbl.Name = "totalLbl";
            this.totalLbl.Size = new System.Drawing.Size(121, 25);
            this.totalLbl.TabIndex = 10;
            this.totalLbl.Text = "Total Price:";
            // 
            // flowerscostOutput
            // 
            this.flowerscostOutput.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.flowerscostOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowerscostOutput.Location = new System.Drawing.Point(309, 250);
            this.flowerscostOutput.Name = "flowerscostOutput";
            this.flowerscostOutput.Size = new System.Drawing.Size(100, 23);
            this.flowerscostOutput.TabIndex = 11;
            // 
            // baseOutput
            // 
            this.baseOutput.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.baseOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.baseOutput.Location = new System.Drawing.Point(309, 293);
            this.baseOutput.Name = "baseOutput";
            this.baseOutput.Size = new System.Drawing.Size(100, 23);
            this.baseOutput.TabIndex = 12;
            // 
            // discountOutput
            // 
            this.discountOutput.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.discountOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.discountOutput.Location = new System.Drawing.Point(309, 338);
            this.discountOutput.Name = "discountOutput";
            this.discountOutput.Size = new System.Drawing.Size(100, 23);
            this.discountOutput.TabIndex = 13;
            this.discountOutput.Click += new System.EventHandler(this.discountOutput_Click);
            // 
            // totalOutput
            // 
            this.totalOutput.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.totalOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalOutput.Location = new System.Drawing.Point(309, 378);
            this.totalOutput.Name = "totalOutput";
            this.totalOutput.Size = new System.Drawing.Size(100, 23);
            this.totalOutput.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.totalOutput);
            this.Controls.Add(this.discountOutput);
            this.Controls.Add(this.baseOutput);
            this.Controls.Add(this.flowerscostOutput);
            this.Controls.Add(this.totalLbl);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.quantityInput);
            this.Controls.Add(this.itemInput);
            this.Controls.Add(this.gardenCombobox);
            this.Controls.Add(this.discountLbl);
            this.Controls.Add(this.baseLbl);
            this.Controls.Add(this.flowerLbl);
            this.Controls.Add(this.quanityLbl);
            this.Controls.Add(this.ieLbl);
            this.Controls.Add(this.gardenLbl);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.DirectoryServices.DirectoryEntry directoryEntry1;
        private System.Windows.Forms.Label gardenLbl;
        private System.Windows.Forms.Label ieLbl;
        private System.Windows.Forms.Label quanityLbl;
        private System.Windows.Forms.Label flowerLbl;
        private System.Windows.Forms.Label baseLbl;
        private System.Windows.Forms.Label discountLbl;
        private System.Windows.Forms.ComboBox gardenCombobox;
        private System.Windows.Forms.TextBox itemInput;
        private System.Windows.Forms.TextBox quantityInput;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Label totalLbl;
        private System.Windows.Forms.Label flowerscostOutput;
        private System.Windows.Forms.Label baseOutput;
        private System.Windows.Forms.Label discountOutput;
        private System.Windows.Forms.Label totalOutput;
    }
}

